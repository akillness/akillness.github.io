BlenderProc example image source bundle
======================================

Upstream repository: https://github.com/DLR-RM/BlenderProc
Pinned revision: 76bd8b82ee19489843578ff045298642197bf883
Repository license: GNU General Public License version 3 (full text in LICENSE).
Repository attribution: DLR-RM / BlenderProc contributors. The pinned repository
contains no separate per-image license notice; coverage is based on that
repository-wide license, not a separate per-image grant.

images/ contains the four unmodified upstream image files, copied byte for byte
from https://raw.githubusercontent.com/DLR-RM/BlenderProc/76bd8b82ee19489843578ff045298642197bf883/images/<filename>.
They are source copies, not additional figures or independently reconstructed
scenes. This bundle does not recreate the original rendering environment or
claim that the code at the pinned revision generated the older images.

SHA-256 of the upstream originals:
basic_rendering_0.jpg 096ff72fba87c31577c04c685c4e27ab92fce792599fbfbc8b7604dad88f4415
basic_rendering_1.jpg 8e93c34d1f8dc4b9c66dd61ddb1896e732728edc79a35ef9a86935a5ba11a7e5
point_clouds_0.png 527dc77f73b0fd287edca459f0616ccbd6b6da3cb13ac2201633c5342b16f57f
point_clouds_1.png 99891da4f33af86d846fa26505bd1c4acf3a6f999390dfbb88167b6c72655025

Change record for the displayed article images, 2026-10-05:
- Both JPEGs remain byte-identical to their upstream originals.
- Each displayed PNG removes its one tEXt chunk whose keyword is Software
  and value is Matplotlib version3.5.1, https://matplotlib.org/.
- The original PNGs inside this archive retain that upstream software label.
  No personal metadata is in that chunk. All other chunks, including pixel
  data, remain byte-identical in the displayed derivatives.
- The displayed PNG hashes are:
  point_clouds_0.png 29586018ef7403115a19a95c95d9e4295caafe2dd7c57401eca95511ab80093a
  point_clouds_1.png 3aaeee4bccc95464cfb935d9d4d1a6dac37230ad9a0a9f7276d10158adb6d1a6

The article provides the license, upstream-image and example-code links next to
each figure. These image files are not covered by the site's general content
license and are not public domain. Preserve appropriate notices and the GPL,
mark changes, convey applicable source, and add no further restrictions when
redistributing them. They are provided without warranty. See LICENSE for the
actual terms; this note is not a replacement for them.
